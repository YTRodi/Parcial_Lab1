#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "orquesta.h"
#include "musico.h"
#include "instrumento.h"
static int generarInstrumentoId(void)
{
	static int id = 0;//0 al 3
	id++;
	return id;
}

void inicializarInstrumento(eInstrumento listInstrumento[], int tInstru)
{
    for(int i = 0; i < tInstru; i++)
    {
        listInstrumento[i].isEmtpy = 1;//LIBREEEEEE
    }
}

int buscarLibreInstrumento(eInstrumento listInstrumento[], int tInstru)
{
    int indice = -1;

    for(int i=0; i < tInstru; i++)
    {
        if( listInstrumento[i].isEmtpy == 1 )
        {
            indice = i;
            break;
        }
    }
    return indice;
}

void mostrarUnInstrumento(eInstrumento listInstrumento)
{
    printf("%5d  %15s    \n\n",
           listInstrumento.id,
           listInstrumento.nombre/*,
           listInstrumento.tipo*/);
}


int imprimirInstrumentos(eInstrumento listInstrumento[],int tInstru)
{
    int flag=0;
    printf("  ID            NOMBRE     \n");
    printf("  --            ------     \n\n");
    for(int i=0; i<tInstru; i++)
    {
        if(listInstrumento[i].isEmtpy == 0)
        {
            mostrarUnInstrumento(listInstrumento[i]);
            flag=1;
        }
    }
    if (flag==0)
    {
        printf("\nNo hay instrumentos que mostrar.\n\n");
    }
    return flag;
}


int altaInstrumentoPorId(eInstrumento listInstrumento[],int tInstru,eInstrumento bufferInstru)
{
    int retorno = -1;
	int index;

	if(listInstrumento != NULL && tInstru >0)
    {
		index = buscarLibreInstrumento(listInstrumento,tInstru);
		if(index >= 0)
        {
			listInstrumento[index] = bufferInstru;
			listInstrumento[index].isEmtpy = 0;
			listInstrumento[index].id = generarInstrumentoId();
			retorno = 0;
		}
	}
	return retorno;
}

int altaInstrumentoMaestra(eInstrumento listInstrumento[], int tInstru)
{

    eInstrumento bInstrumento;
	int retorno = -1;

	system("cls");
	printf("\nAlta instrumento\n\n");

	if (buscarLibreInstrumento(listInstrumento, tInstru) == -1)
    {
		printf("\n--Sistema completo.--\n\n");
	}
	else
    {
        if(getString(bInstrumento.nombre,"Ingrese nombre del instrumento:","Error. reingrese...\n",1,50,3) != -1)
        {

            if(getInt(&bInstrumento.tipo,"Elija tipo: ","Error. reingrese...\n",1,3,3) != -1)
            {
                if(altaInstrumentoPorId(listInstrumento,tInstru,bInstrumento) == 0)
                {
                    printf("\n--Alta instrumento exitosa--\n\n");
                    retorno = 0;
                }
            }
        }
        if (retorno != 0)
        {
            printf("Error al cargar los datos\n");
        }
    }
    return retorno;
}


void hardCodearInstrumentosConId(eInstrumento listInstrumento[],int tInstru)
{
    eInstrumento bInstru;

    //char tipo[] [50] = {"Cuerdas","Viento-madera","Viento-metal","percusion"};


    char nombre[] [50] ={"Cuerdas","Viento-madera","Viento-metal","Percusion"};

    int tipo[] = {1,2,3,4};

    for(int i = 0; i<4; i++)//EN EL SEGUNDO PARAMETRO "i < LAS COSAS QUE TENGO HARDCODEADAS".
    {
        strcpy(bInstru.nombre,nombre[i]);
        bInstru.tipo = tipo[i];

        altaInstrumentoPorId(listInstrumento,50,bInstru);

    }
}


/*int cargarDescInstrumento(int id, eInstrumento listInstrumentos[], int tInstru, char desc[])
{
    int todoOk = 0;

    for(int i = 0; i< tInstru; i++)
    {
        if(id == listInstrumentos[i].id)
        {
            strcpy(desc,listInstrumentos[i].descripcion);
            todoOk = 1;
            break;
        }
    }
    return todoOk;
}*/
