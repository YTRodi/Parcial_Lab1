#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "orquesta.h"
#include "musico.h"
#include "instrumento.h"



//NO HACE FALTA PONERLA EN EL .h
static int generarMusicoId(void)
{
	static int id = 100;
	id++;
	return id;
}

void inicializarMusico(eMusico listMusico[], int tMusic)
{
    for(int i = 0; i < tMusic; i++)
    {
        listMusico[i].isEmpty = 1;//LIBREEEEEE
    }
}

int buscarLibreMusico(eMusico listMusico[], int tMusic)
{
    int indice = -1;

    for(int i=0; i < tMusic; i++)
    {
        if( listMusico[i].isEmpty == 1 )
        {
            indice = i;
            break;
        }
    }
    return indice;
}

/*void mostrarUnMusico(eMusico listMusico, eInstrumento listInstru[], int tInstru)
{
    char descripcionInstrumento[50];

    cargarDescInstrumento(listMusico.id,listInstru,tInstru,descripcionInstrumento);

    printf("%5d  %10s   %10s    %5d     %d  %s\n\n",
           listMusico.id,
           listMusico.nombre,
           listMusico.apellido,
           listMusico.edad,
           listMusico.idInstrumento,
           descripcionInstrumento);
}*/

/*int imprimirMusicos(eMusico listMusico[],int tMusic)
{
    int flag=0;
    printf("  ID       NOMBRE     APELLIDO     EDAD    NombreInstru    tipoInstru\n");
    printf("  --       ------     --------     ----    ------------    ----------\n\n");
    for(int i=0; i<tMusic; i++)
    {
        if(listMusico[i].isEmpty==0)
        {
            mostrarUnMusico(listMusico[i]);
            flag=1;
        }
    }
    if (flag==0)
    {
        printf("\nNo hay musicos que mostrar.\n\n");
    }
    return flag;
}*/



int altaMusicoPorId(eMusico listMusico[], int tMusic, eMusico bufferMusico)
{
	int retorno = -1;
	int index;

	if(listMusico != NULL && tMusic >0)
    {
		index = buscarLibreMusico(listMusico,tMusic);
		if(index >= 0)
        {
			listMusico[index] = bufferMusico;
			listMusico[index].isEmpty = 0;
			listMusico[index].id = generarMusicoId();
			retorno = 0;
		}
	}
	return retorno;
}






/*
int altaMusicoMaestra(eMusico listMusico[],int tMusic)
{
	eMusico BufferMusico;
	int retorno = -1;

	//int validacion1;//PARA LA ORQUESTA.
	//int validacion2;//PARA EL INSTRUMENTO.

	system("cls");
	printf("\nAlta musico\n");

	if (buscarLibreMusico(listMusico, tMusic) == -1)
    {
		printf("\n--Sistema completo.--\n\n");
	}
	else
    {
        if(getString(BufferMusico.nombre,"Ingrese nombre: ", "ERROR\n",1,50,3)!=-1)
        {
            if(getString(BufferMusico.apellido,"Ingrese apellido: ","ERROR\n",1,50,3)!=-1)
            {
                if(getInt(&BufferMusico.edad,"Ingrese edad: ","ERROR\n",1,1000,3)!=-1)
                {
                    if(altaMusicoPorId(listMusico,tMusic,BufferMusico)==0)
                    {
                        printf("\n--Alta de musico exitosa--\n\n");
                        retorno = 0;
                    }
                }
            }
        }
        if (retorno != 0)
        {
            printf("Error al cargar los datos\n");
        }
    }
    return retorno;
}*/

int buscarPorIdMusico(eMusico listMusico[],int tMusic, int id)//BUSCAR ALUMNO
{
    int indice = -1;

    for(int i=0; i < tMusic; i++)
    {
        if( listMusico[i].id == id && listMusico[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

/*int modificarMusico(eMusico listMusico[],int tMusic)
{
    int todoOk = 0;
    int id;
    int index;
    //int flagValid = 0;
    //int flagValidOrq = 0;

    system("cls");
	printf("\n--Modificar musico--\n");

    imprimirMusicos(listMusico,tMusic);

    getInt(&id,"Ingrese ID: ","Error\n",1,10000,2);

    index = buscarPorIdMusico(listMusico,tMusic,id);

    if(index == -1)
    {
        printf("\nNo existe un musico con ese ID\n\n");
    }
    else
    {

        switch(menuModifMusico())
        {
            case 1:
                getString(listMusico[index].nombre,"Ingrese nuevo nombre: ", "Error. debe contener entre 2 y 35 caracteres",2,35,2);
                todoOk = 1;
                break;
            case 2:

                //FALTA TESTEAR, FALTA MOSTRAR A QUE ORQUESTA PERTENECE EL MUSICO ANTES DE MODIFICARLA CLARO...

                //imprimirOrquestas(listOrquesta,tOrq);
                getInt(&listMusico[index].idOrquesta,"Ingrese nueva orquesta donde pertenece: ","Error, reingrese\n",1,10000,3);
                todoOk = 1;
                break;
        }

    }

    return todoOk;
}*/

int menuModifMusico()
{
    int option;
    printf("\n--MODIFICAR MUSICO---\n\n");
    printf("\n*Elija que desea modificar*\n");
    printf("1 - Modificar edad\n2 - Modificar orquesta\n3 - salir\n");
    getInt(&option,"Elija opcion: ", "Error. opcion invalida\n",1,3,2);
    return option;
}

int bajaMusico(eMusico listMusico[],int tMusic)
{
    int id;
    int index;
    char confirma;
    int todoOk = 0;

    imprimirMusicos(listMusico,tMusic);


    getInt(&id,"\nIngrese ID a dar de baja: ","Error",1,200,2);


    //BUSCAR ALUMNO...
    index = buscarPorIdMusico(listMusico,tMusic,id);


    if(index == -1)
    {
        printf("\nNo existe musico con ese ID.\n");
        printf("\n...Redireccionando...\n\n");
    }
    else
    {
        printf("\nACA ENTRO??\n");
        mostrarUnMusico(listMusico[index]);

        printf("confirma baja? <s/n>: ");
        fflush(stdin);
        scanf("%c",&confirma);

        if(confirma == 's')
        {
            listMusico[index].isEmpty = 1;//1 ES LIBRE.
            printf("\nBaja exitosa.\n\n");
            todoOk = 1;
        }
        else if(confirma == 'n')
        {
            printf("\nSe ha cancelado la operacion.\n\n");
        }
    }

    return todoOk;
}

























void hardCodearMusicosConId(eMusico listMusico[],int tMusic)
{
    eMusico bMusico;

    char nombre[] [50] ={"Yago","Camila","Facundo","Joaquin","Humberto","Norma","Mario","David","Lucia","Hugo","Daniel","Alba","Adrian","Martin","Sara","Carla","Claudia","Valeria","Paula","Sofia"};

    char apellido[] [50] = {"Rodi","Roy","Toro","Vasquez","Gomez","Perez","Pereyta","Torres","Medina","Acosta","Sanchez","Fernandez","Rodriguez","Molina","Cabrera","Diaz","Perez","Dominguez","Luna","Godoy"};

    int edad[] = {19,5,50,41,15,9,17,27,44,36,30,15,13,21,28,34,39,48,44,40};

    /*int nombreInstru[] [50] = {
    "Viento-madera",
    "Cuerdas",
    "Viento-madera",
    "Viento-Metal",
    "Percusion",
    "Cuerdas",
    "Viento-Metal",
    "Cuerdas",
    "Viento-madera",
    "Percusion",
    "Cuerdas",
    "Viento-madera",
    "Percusion",
    "Viento-Metal",
    "Cuerdas",
    "Cuerdas",
    "Percusion",
    "Viento-Metal",
    "Viento-Metal",
    "Cuerdas"
    };

    int tipo[] = {2,1,2,3,4,1,3,1,2,4,1,2,4,3,1,1,4,3,3,1};*/

    for(int i = 0; i<20; i++)//EN EL SEGUNDO PARAMETRO "i < LAS COSAS QUE TENGO HARDCODEADAS".
    {
        strcpy(bMusico.nombre,nombre[i]);
        strcpy(bMusico.apellido ,apellido[i]);
        bMusico.edad = edad[i];

        altaMusicoPorId(listMusico,100,bMusico);
    }

}
