#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "orquesta.h"
#include "musico.h"
#include "instrumento.h"

//NO HACE FALTA PONERLA EN EL .h
static int generarOrquestaId(void)
{
	static int id = 1000;
	id++;
	return id;
}


int menuTeatro()
{
    int option;
    system("cls");
    printf("---ABM TEATRO---\n\n");
    printf("1-ALTA orquesta\n");
    printf("2-BAJA orquesta\n");
    printf("3-IMPRIMIR orquestas\n");
    printf("4-ALTA musico\n");
    printf("5-MODIFICAR musico\n");
    printf("6-BAJA musico\n");
    printf("7-IMPRIMIR musicoS\n");
    printf("8-ALTA instrumento\n");
    printf("9-IMPRIMIR instrumentos\n");
    printf("10-SALIR\n");
    getInt(&option,"\nIngrese opcion: ","Error. opcion no valida",1,10,2);
    return option;
}

void inicializarOrquesta(eOrquesta listOrquesta[], int tOrq)
{
    for(int i = 0; i < tOrq; i++)
    {
        listOrquesta[i].isEmpty = 1;//LIBREEEEEE
    }
}


int buscarLibreOrquesta(eOrquesta listOrquesta[], int tOrq)
{
    int indice = -1;

    for(int i=0; i < tOrq; i++)
    {
        if( listOrquesta[i].isEmpty == 1 )
        {
            indice = i;
            break;
        }
    }
    return indice;
}


void mostrarUnaOrquesta(eOrquesta listOrquesta)
{
    printf("%5d       %10s   %10s    %5d\n\n",
           listOrquesta.id,
           listOrquesta.nombre,
           listOrquesta.lugar,
           listOrquesta.tipo);
}


int imprimirOrquestas(eOrquesta listOrquesta[],int tOrq)
{
    int flag=0;
    printf("  ID            NOMBRE        LUGAR     TIPO\n");
    printf("  --            ------        -----     ----\n\n");
    for(int i=0; i<tOrq; i++)
    {
        if(listOrquesta[i].isEmpty==0)
        {
            mostrarUnaOrquesta(listOrquesta[i]);
            flag=1;
        }
    }
    if (flag==0)
    {
        printf("\nNo hay orquestas que mostrar\n");
    }
    return flag;
}


//FUNC ALTA (INICIO)-----------------------------------------------------------------------------------
int altaOrquestaPorId(eOrquesta listOrquesta[], int tOrq, eOrquesta BufferOrquesta)
{
	int retorno = -1;
	int index;

	if(listOrquesta != NULL && tOrq >0)
    {
		index = buscarLibreOrquesta(listOrquesta,tOrq);
		if(index >= 0)
        {
			listOrquesta[index] = BufferOrquesta;
			listOrquesta[index].isEmpty = 0;
			listOrquesta[index].id = generarOrquestaId();
			retorno = 0;
		}
	}
	return retorno;
}

int altaOrquestaMaestra(eOrquesta listOrquesta[], int tOrq)
{
	eOrquesta BufferOrquesta;
	int retorno = -1;

	system("cls");
	printf("\nAlta orquesta\n");

	if (buscarLibreOrquesta(listOrquesta, tOrq) == -1)
    {
		printf("\n--Sistema completo.--\n\n");
	}
	else
    {
		if (getString(BufferOrquesta.nombre, "<1-50 caract>\nIngrese nombre: ", "Error\n", 1, 50, 3) != -1)
        {
			if (getString(BufferOrquesta.lugar, "<1-50 caract>\nIngrese lugar: ", "Error\n", 1,50, 3) != -1)
            {
               if(getInt(&BufferOrquesta.tipo,"\nACA LLAMAR A MOSTRAR DESCRIPCION DE ORQUESTAS\n\n<1-3>\nIngrese tipo: ","Reingrese tipo\n",1,3,3) != -1)
                {

                    if (altaOrquestaPorId(listOrquesta,tOrq,BufferOrquesta)== 0)
                    {
                        printf("\n--Alta exitosa--\n");
                        retorno = 0;
                    }
                }

            }
        }
        if (retorno != 0)
        {
            printf("Error al cargar los datos\n");
        }
    }
    return retorno;
}
//FUNC ALTA (FIN)-----------------------------------------------------------------------------------


//FUNC BAJA (INICIO)-----------------------------------------------------------------------------------
int buscarPorIdOrquesta(eOrquesta listOrquesta[],int tOrq, int id)//BUSCAR ALUMNO
{
    int indice = -1;

    for(int i=0; i < tOrq; i++)
    {
        if( listOrquesta[i].id == id && listOrquesta[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

int bajaOrquesta(eOrquesta listOrquesta[],int tOrq)
{
    int id;
    int index;
    char confirma;
    int todoOk = 0;

    imprimirOrquestas(listOrquesta,tOrq);

    getInt(&id,"\nIngrese ID a dar de baja: ","Error",1,200,2);


    //BUSCAR ALUMNO...
    index = buscarPorIdOrquesta(listOrquesta,tOrq,id);

    if(index == -1)
    {
        printf("\nNo existe orquesta con ese ID.\n");
        printf("\n...Redireccionando...\n\n");
    }
    else
    {
        //printf("\nACA ENTRO??\n");

        mostrarUnaOrquesta(listOrquesta[index]);

        printf("confirma baja? <s/n>: ");
        fflush(stdin);
        scanf("%c",&confirma);

        if(confirma == 's')
        {
            listOrquesta[index].isEmpty = 1;//1 ES LIBRE.
            printf("\nBaja exitosa.\n\n");
            todoOk = 1;
        }
        else if(confirma == 'n')
        {
            printf("\nSe ha cancelado la operacion.\n\n");
        }
    }

    return todoOk;
}
//FUNC BAJA (FIN)-----------------------------------------------------------------------------------



























void hardCodearOrquestaConId(eOrquesta listOrquesta[],int cantidad)
{
    eOrquesta bOrquesta;

    char nombre[] [50] ={"Yaggi's","Camu's","Royal","Berlin","London","Chicago","Bavarian","Cleveland","Los Angeles","Budapest","Dresden"};

    char lugar[] [50] = {"USA","BA","Holanda","Alemania","UK","USA","Munich","USA-Ohio","USA-LA","Hungria","Sajona"};

    int tipo[] = {19,5,50,41,15,9,17,27,44,36,30};

    for(int i = 0; i<11; i++)//EN EL SEGUNDO PARAMETRO "i < LAS COSAS QUE TENGO HARDCODEADAS".
    {
        strcpy(bOrquesta.nombre,nombre[i]);
        strcpy(bOrquesta.lugar,lugar[i]);
        bOrquesta.tipo = tipo[i];

        altaOrquestaPorId(listOrquesta,100,bOrquesta);
    }

}




