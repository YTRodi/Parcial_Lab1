typedef struct
{
    char nombre[50];
    char lugar[50];
    int tipo;
    int id;
    int isEmpty;
}eOrquesta;



//MENU TEATRO
int menuTeatro();


//FUNC ORQUESTA
void inicializarOrquesta(eOrquesta listOrquesta[], int tOrq);
int buscarLibreOrquesta(eOrquesta listOrquesta[], int tOrq);
void mostrarUnaOrquesta(eOrquesta listOrquesta);
int imprimirOrquestas(eOrquesta listOrquesta[],int tOrq);

//ALTA ORQUESTA
int altaOrquestaPorId(eOrquesta listOrquesta[], int tOrq, eOrquesta auxL);
int altaOrquestaMaestra(eOrquesta listOrquesta[], int tOrq);

//BAJA ORQUESTA
int buscarPorIdOrquesta(eOrquesta listOrquesta[],int tOrq, int id);
int bajaOrquesta(eOrquesta listOrquesta[],int tOrq);

//HARDCODEO
void hardCodearOrquestaConId(eOrquesta listOrquesta[],int cantidad);




