#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "orquesta.h"
#include "musico.h"
#include "instrumento.h"


#define TAMOR 12 // -11 DEL HARDCODEO: PUEDO AGREGAR 1 MAS.
#define TAMMUSIC 1000
#define TAMINSTRU 20

#define QTY_ORQ 12

/*
   IMPTY = 1 LIBRE
   EMPTY = 0 OCUPADO

LA CONCHA BIEN DE SU MADRE
*/

/* HACER LOS DOXY GEN PARA EL FANTASMA ***/

int altaMusico(eMusico listMusico[], int tMusic,eOrquesta listOrquesta[],int tOrq, eInstrumento listInstrumento[], int tInstru);
void mostrarUnMusico(eMusico listMusico);

void mostrarUnMusicoConInstrumento(eMusico listMusico, eInstrumento listInstru[], int tInstru);
int cargarDescInstrumento(int id, eInstrumento listInstrumentos[], int tInstru, char desc[],int *auxTipo);
void imprimirUnMusicoConInstrumento(eMusico listMusico,eInstrumento listInstrumentos[],int tInstru);
int imprimirMusicosConInstrumento(eMusico listMusico[],int tMusic,eInstrumento listInstrumentos[],int tInstru);

void mostrarMusicos(eMusico vec[], int tam);
void mostrarUnSoloMusico(eMusico vec);


int main()
{

    eOrquesta arrayOrquesta[TAMOR];
    eMusico arrayMusico[TAMMUSIC];
    eInstrumento ArrayInstrumento[TAMINSTRU];

    //int id = 100;
    char exit = 'n';

    //INICIALIZADORES
    inicializarOrquesta(arrayOrquesta,TAMOR);
    inicializarMusico(arrayMusico,TAMMUSIC);
    inicializarInstrumento(ArrayInstrumento,TAMINSTRU);

    //HARDCODEO
    hardCodearOrquestaConId(arrayOrquesta,TAMOR);
    hardCodearMusicosConId(arrayMusico,TAMMUSIC);
    hardCodearInstrumentosConId(ArrayInstrumento,TAMINSTRU);

    do
    {
        switch(menuTeatro())
        {
            case 1:
                altaOrquestaMaestra(arrayOrquesta,TAMOR);
                break;
            case 2:
                bajaOrquesta(arrayOrquesta,TAMOR);
                break;
            case 3:
                imprimirOrquestas(arrayOrquesta,TAMOR);
                break;
            case 4:
                altaMusico(arrayMusico,TAMMUSIC,arrayOrquesta,TAMOR,ArrayInstrumento,TAMINSTRU);
                break;
            case 5:
                modificarMusico(arrayMusico,TAMMUSIC);
                break;
            case 6:
                bajaMusico(arrayMusico,TAMMUSIC);
                break;
            case 7:
                imprimirMusicosConInstrumento(arrayMusico,TAMMUSIC,ArrayInstrumento,TAMINSTRU);
                break;
            case 8:
                altaInstrumentoMaestra(ArrayInstrumento,TAMINSTRU);
                break;
            case 9:
                imprimirInstrumentos(ArrayInstrumento,TAMINSTRU);
                break;
            case 10:
                printf("Confirma salir? <s/n>: ");
                fflush(stdin);
                exit = getche();
                printf("\n\n");
                break;
        }
        system("pause");

    }while(exit=='n');

    return 0;
}

//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------------------------

//ACA EMPIEZAN LAS MODIFICACIONES EN EL ALTA(CON ID DE LA ORQUESTA QUE TOCA, ID DEL INSTRUMENTO) ,BAJA, MODIFICACION
int altaMusico(eMusico listMusico[], int tMusic,eOrquesta listOrquesta[],int tOrq, eInstrumento listInstrumento[], int tInstru)
{
	eMusico bMusic;
	int retorno = -1;
	int validacion;
	int validacion2;


	system("cls");
	printf("\n--Alta musico--\n");

	if (buscarLibreMusico(listMusico, tMusic) == -1)
    {
		printf("ERROR,No hay mas lugar  para ingresar \n ");
	}
	else
    {
		if (getString(bMusic.nombre, "\nIngrese nombre: ", "\nError. Reingrese nombre.", 0, 50, 3)!= -1)
        {
			if (getString(bMusic.apellido, "\nIngrese apellido: ", "\nError. Reingrese apellido.", 0,50, 3) == 0)
            {
				if (getInt(&bMusic.edad,"\nIngrese edad: ", "\nError. Reingrese edad.", 1,100, 3) != -1)
                {
                    validacion = imprimirOrquestas(listOrquesta,tOrq);

                    if(validacion==1)
                    {
                         if  (getInt(&bMusic.idOrquesta,"\nIngrese ID orquesta en la que toca: ","\nReingrese.",1001,1051,3)==0)//LOS ID DE ORQ EMPIEZAN EN 1001 Y SE PUEDEN CARGAR SOLO 50.
                        {
                            validacion2 = imprimirInstrumentos(listInstrumento,tInstru);

                            if(validacion2==1)
                            {
                                if(getInt(&bMusic.idInstrumento,"\nIngrese ID instrumento que toca: ","\nReingrese.",1,4,3)==0)
                                {

                                    if (altaMusicoPorId(listMusico,tMusic,bMusic)== 0)
                                    {
                                    printf("\n--Alta exitosa\n\n");
                                    retorno = 0;

                                    }

                                }

                            }



                        }

                    }

                }
            }
        }
        if (retorno != 0)
        {
            printf("Error al cargar los datos\n");
        }
    }
    return retorno;
}


void mostrarUnMusicoConInstrumento(eMusico listMusico, eInstrumento listInstru[], int tInstru)
{
    printf("%5d  %10s   %10s    %5d \n\n",
           listMusico.id,
           listMusico.nombre,
           listMusico.apellido,
           listMusico.edad);
}

void imprimirUnMusicoConInstrumento(eMusico listMusico,eInstrumento listInstrumentos[],int tInstru)
{
    char descripcionInstrumento[50];
    int auxTipo = 0;

    cargarDescInstrumento(listMusico.idInstrumento,listInstrumentos,tInstru,descripcionInstrumento,&auxTipo);

    printf("%5d  %10s   %10s    %5d    %5s       %7d\n\n",
           listMusico.id,
           listMusico.nombre,
           listMusico.apellido,
           listMusico.edad,
           descripcionInstrumento,
           listMusico.idInstrumento);

    /*switch(auxTipo)
    {
        case 1:
            printf("Cuerdas");
            break;
        case 2:
            printf("Viento madera");
            break;
        case 3:
            printf("Viento metal");
            break;
        case 4:
            printf("Percusion");
            break;
    }*/
}

int imprimirMusicosConInstrumento(eMusico listMusico[],int tMusic,eInstrumento listInstrumentos[],int tInstru)
{
    int flag=0;
    printf("  ID       NOMBRE     APELLIDO     EDAD    NombreInstru    tipoInstru\n");
    printf("  --       ------     --------     ----    ------------    ----------\n\n");
    for(int i=0; i<tMusic; i++)
    {
        if(listMusico[i].isEmpty==0)
        {
            imprimirUnMusicoConInstrumento(listMusico[i],listInstrumentos,tInstru);
            //mostrarUnMusico(listMusico[i]);
            flag=1;
        }
    }
    if (flag==0)
    {
        printf("\nNo hay musicos que mostrar.\n\n");
    }
    return flag;
}


int cargarDescInstrumento(int id, eInstrumento listInstrumentos[], int tInstru, char desc[],int *auxTipo)
{
    int todoOk = 0;

    for(int i = 0; i< tInstru; i++)
    {
        if(id == listInstrumentos[i].id)
        {
            strcpy(desc,listInstrumentos[i].nombre);
            *auxTipo=listInstrumentos[i].tipo;
            todoOk = 1;
            break;
        }
    }
    return todoOk;
}

void mostrarMusicos(eMusico vec[], int tam)
{

   int flag=0;

    for(int i=0; i<tam; i++)
    {
        if(vec[i].isEmpty==0)
        {
            mostrarUnSoloMusico(vec[i]);
            flag=1;
        }

    }
    if (flag==0)
    {
        printf("\nNo hay musicos que mostrar\n");
    }
}

void mostrarUnSoloMusico(eMusico vec)
{

    printf("%d  %10s   %10s  %d\n",
           vec.id,
           vec.nombre,
           vec.apellido,
           vec.edad);
}

int modificarMusico(eMusico listMusico[],int tMusic)
{
    int todoOk = 0;
    int id;
    int index;
    //int flagValid = 0;
    //int flagValidOrq = 0;

    system("cls");
	printf("\n--Modificar musico--\n");

	//MOSTRAR LA LISTA DE MUSICOS ETC ETC
    //imprimirMusicos(listMusico,tMusic,);
    mostrarMusicos(listMusico,tMusic);

    getInt(&id,"Ingrese ID: ","Error\n",1,10000,2);

    index = buscarPorIdMusico(listMusico,tMusic,id);

    if(index == -1)
    {
        printf("\nNo existe un musico con ese ID\n\n");
    }
    else
    {

        switch(menuModifMusico())
        {
            case 1:
                getInt(&listMusico[index].edad,"Ingrese nueva edad: ","ERROR",1,100,3);
                //getString(listMusico[index].nombre,"Ingrese nuevo nombre: ", "Error. debe contener entre 2 y 35 caracteres",2,35,2);
                todoOk = 1;
                break;
            case 2:

                //FALTA TESTEAR, FALTA MOSTRAR A QUE ORQUESTA PERTENECE EL MUSICO ANTES DE MODIFICARLA CLARO...

                //imprimirOrquestas(listOrquesta,tOrq);
                getInt(&listMusico[index].idOrquesta,"Ingrese nueva orquesta donde pertenece: ","Error, reingrese\n",1,10000,3);
                todoOk = 1;
                break;
        }

    }

    return todoOk;
}
