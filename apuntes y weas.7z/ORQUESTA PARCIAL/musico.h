typedef struct
{
    char nombre[50];
    char apellido[50];
    int edad;
    int id;
    int idOrquesta;
    int idInstrumento;
    int isEmpty;
}eMusico;



//1000 COMO MAX

//FUNC MUSICO
void inicializarMusico(eMusico listMusico[], int tMusic);
int buscarLibreMusico(eMusico listMusico[], int tMusic);

//void mostrarUnMusico(eMusico listMusico);

//void mostrarUnMusico(eMusico listMusico, eInstrumento listInstru[], int tInstru);
//int imprimirMusicos(eMusico listMusico[],int tMusic);

//ALTA MUSICO
int altaMusicoPorId(eMusico listMusico[], int tMusic, eMusico bufferMusico);

//int altaMusicoPiola(eMusico listMusico[], int tMusic,  eInstrumento instru[], int tInstru , eOrquesta orq[], int tOrq);
//int altaMusicoMaestra(eMusico listMusico[],int tMusic);



//MOD MUSICO
int buscarPorIdMusico(eMusico listMusico[],int tMusic, int id);
//int modificarMusico(eMusico listMusico[],int tMusic);
int menuModifMusico();

//BAJA MUSICO
int bajaMusico(eMusico listMusico[],int tMusic);

//HARDCODEO
void hardCodearMusicosConId(eMusico listMusico[],int tMusic);









