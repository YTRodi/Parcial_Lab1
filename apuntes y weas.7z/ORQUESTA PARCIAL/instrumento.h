typedef struct
{
    char nombre[50];
    int tipo;
    int id;
    int isEmtpy;
}eInstrumento;

//20 COMO MAXIMO


//FUNC INSTRUMENTOS
void inicializarInstrumento(eInstrumento listInstrumento[], int tInstru);
int buscarLibreInstrumento(eInstrumento listInstrumento[], int tInstru);
void mostrarUnInstrumento(eInstrumento listInstrumento);
int imprimirInstrumentos(eInstrumento listInstrumento[],int tInstru);

//ALTA INSTRUMENTO
int altaInstrumentoPorId(eInstrumento listInstrumento[],int tInstru,eInstrumento bufferInstru);
int altaInstrumentoMaestra(eInstrumento listInstrumento[], int tInstru);


//HARDCODEO
void hardCodearInstrumentosConId(eInstrumento listInstrumento[],int tInstru);

//int cargarDescInstrumento(int id, eInstrumento listInstrumentos[], int tInstru, char desc[]);

