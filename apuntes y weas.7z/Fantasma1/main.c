#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "ghostUno.h"

#define TAMGHOST 100


//FALTAN LOS DOXYGEN
//FALTA ORDENAR EMPLEADOS (SORT EMPLOYEES!!!) esta en el tp2

int main()
{
    //1ro - CREO LOS ARRAYS
    eFantasma arrayFantasma[TAMGHOST];


    char exit = 'n';

    //2ro = INICIALIZAR.
    inicializarFantasma(arrayFantasma,TAMGHOST);

    //HARDCODEO
    hardCodearFantasmasConId(arrayFantasma,TAMGHOST,1);

    do
    {
        switch(menuFantasmaGeneralUno())
        {
            case 1:
                altaFantasmaMaestra(arrayFantasma,TAMGHOST);
            //printf("ALTA FANTASMA\n");
            break;

            case 2:
                modificarFantasma(arrayFantasma,TAMGHOST);
            //printf("MODIFICAR FANTASMA\n");
            break;

            case 3:
                bajaFantasma(arrayFantasma,TAMGHOST);
            //printf("BAJA FANTASMA\n");
            break;

            case 4:
                imprimirFantasmas(arrayFantasma,TAMGHOST);
            //printf("IMPRIMIR FANTASMAS\n");
            break;

            case 5:
            printf("Confirma salir? <s/n>: ");
            fflush(stdin);
            exit = getche();
            printf("\n\n");
            break;

            default:
                printf("\n...Redireccionando al menu...\n");

        }
    system("pause");

    }while(exit == 'n');

    return 0;
}
