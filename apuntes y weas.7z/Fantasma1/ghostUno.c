#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
#include "utn.h"
#include "ghostUno.h"

//NO HACE FALTA PONERLA EN EL .h


/** \brief Muestra un menu de opciones.
 *
 * \return int La opcion elegida.
 *
 */
int menuFantasmaGeneralUno()
{
    int option;
    system("cls");
    printf("---ABM (GENERICO)---\n\n");
    printf("1 - ALTA fantasma\n");
    printf("2 - MODIFICAR fantasma\n");
    printf("3 - BAJA fantasma\n");
    printf("4 - IMPRIMIR fantasmaS\n");
    printf("\n...ACA AGREGAR LO QUE PIDEN(CON SUS RESPECTIVAS OPCIONES) etc etc...\n\n");
    printf("5 - SALIR\n");
    getInt(&option,"\nIngrese opcion: ","Error. opcion no valida",1,5,2);
    //ACA LIMITAR LA OPCION, MUY IMPORTANTE!!!!!!!!!!!!!!!!!!!!!
    return option;
}


/** \brief Genera un id autoincremental.
 *
 * \return int Id.
 *
 */
static int generarFantasmaId(void)
{
	static int id = 1000;
	id++;
	return id;
}


/** \brief Inicializa el array del tipo estructura de modo que el estado isEmpty
 *         de cada posicion del array sea 1 en todas sus posiciones.
 *
 * \param listFantasma[] Array de estructura a inicializar.
 * \param tFant Longitud/tama�o del Array de estructura.
 *
 */
void inicializarFantasma(eFantasma listFantasma[], int tFant)
{
    for(int i = 0; i < tFant; i++)
    {
        listFantasma[i].isEmpty = 1;//LIBREEEEEE
    }
}


/** \brief Encuentra la primera posicion disponible del
           array pasado por parametro o informa si esta lleno.
 *
 * \param listFantasma[] Array del tipo estructura en donde se buscara la posicion libre.
 * \param tFant Longitud/tama�o del Array de estructura.
 * \return int Retorna el �ndice de la primera posicion disponible que encuentra.
 *
 */
int buscarLibreFantasma(eFantasma listFantasma[], int tFant)
{
    int indice = -1;

    for(int i=0; i < tFant; i++)
    {
        if(listFantasma[i].isEmpty == 1)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

/** \brief Muestra por pantalla a un ITEM pasado por parametro.
 *
 * \param listFantasma ITEM a ser mostrado.
 * \return void No retorna nada.
 *
 */
void mostrarUnFantasma(eFantasma listFantasma)
{
    printf("%5d  %10s   %10s    %5d     %.2f\n\n",
           listFantasma.id,
           listFantasma.nombre,
           listFantasma.apellido,
           listFantasma.edad,
           listFantasma.salario);
}

/** \brief Imprime por pantalla todo el array del ITEM pasado por parametro.
 *
 * \param listFantasma[] Array del tipo estructura a ser mostrado.
 * \param tFant Longitud/tama�o del Array de estructura.
 * \return int Retorna [0] si no hay ITEM que mostrar - [1] Todo OK
 *
 */
int imprimirFantasmas(eFantasma listFantasma[],int tFant)
{
    int flag=0;
    printf("  ID       NOMBRE     APELLIDO     EDAD       SALARIO\n");
    printf("  --       ------     --------     ----       -------\n\n");
    for(int i=0; i<tFant; i++)
    {
        if(listFantasma[i].isEmpty == 0)
        {
            mostrarUnFantasma(listFantasma[i]);
            flag=1;
        }
    }
    if (flag==0)
    {
        printf("\nNo hay --GENERICO-- que mostrar.\n\n");
    }
    return flag;
}

//ALTA FANTASMA

/** \brief Busca libre.
 *         Verifica si el indice es menor o igual a 0
 *         Si esta todo bien: iguala la lista con el buffer,
 *         pone el campo isEmpty en 0, iguala el id con la funcion generarId
 *
 * \param listFantasma[] Array del tipo estructura a verificar.
 * \param tFant Longitud/tama�o del Array de estructura.
 * \param bufferFantasma eFantasma
 * \return int Retorna [-1] si hubo un ERROR - [0] Todo OK.
 *
 */
int altaFantasmaPorId(eFantasma listFantasma[], int tFant, eFantasma bufferFantasma)
{
	int retorno = -1;
	int index;

	if(listFantasma != NULL && tFant >0)
    {
		index = buscarLibreFantasma(listFantasma,tFant);
		if(index >= 0)
        {
            listFantasma[index] = bufferFantasma;
            listFantasma[index].isEmpty = 0;
            listFantasma[index].id = generarFantasmaId();
            retorno = 0;
		}
	}
	return retorno;
}

/** \brief Da de alta al ITEM.
 *         Se fija si hay lugar libre.
 *         Se lo hay, pide los datos.
 *
 * \param listFantasma[] Array del tipo estructura a dar de alta.
 * \param tFant Longitud/tama�o del Array de estructura.
 * \return int Retorna [-1] si hubo un ERROR - [0] Todo OK.
 *
 */
int altaFantasmaMaestra(eFantasma listFantasma[],int tFant)
{
	eFantasma bufferFantasma;
	int retorno = -1;

	//int validacion1;//PARA LA ORQUESTA.
	//int validacion2;//PARA EL INSTRUMENTO.

	system("cls");
	printf("\nAlta --GENERICO--\n");

	if (buscarLibreFantasma(listFantasma, tFant) == -1)
    {
		printf("\n--Sistema completo.--\n\n");
	}
	else
    {
        if(getString(bufferFantasma.nombre,"\nIngrese nombre: ", "ERROR\n",1,50,3)!=-1)
        {
            if(getString(bufferFantasma.apellido,"\nIngrese apellido: ","ERROR\n",1,50,3)!=-1)
            {
                if(getFloat(&bufferFantasma.salario,"\nEntre <1.0 - 10000000.0 num float.>\nIngrese salario: ","\nERROR, debe ingresar un numero",1.0,10000000.0,2)!=-1)
                {
                    if(getInt(&bufferFantasma.edad,"\nIngrese edad: ","ERROR\n",1,1000,3)!=-1)
                    {
                        if(altaFantasmaPorId(listFantasma,tFant,bufferFantasma)==0)
                        {
                        printf("\n--Alta de --GENERICO-- exitosa--\n\n");
                        retorno = 0;
                        //SI NO FUNCIONA. SACARLE LO DE SALARIO (FUE LO ULTIMO QUE AGREGUE)
                        }
                    }
                }

            }
        }
        if (retorno != 0)
        {
            printf("Error al cargar los datos\n");
        }
    }
    return retorno;
}

//MODIFICACION
//ES BUSCAR ALUMNO....
/** \brief Busca en el array del tipo estructura el ITEM que coincida con el
 *         id pasado  por parametro.
 *
 * \param listFantasma[] Array del tipo estructura en el cual se buscar al ITEM.
 * \param tFant Longitud/tama�o del Array de estructura.
 * \param id Id del ITEM a buscar.
 * \return int Retorna el indice en el cual se encuentra el empledo buscado por ID
 *             o [-1] en caso de no encontrarlo.
 *
 */
int buscarPorIdFantasma(eFantasma listFantasma[],int tFant, int id)
{
    int indice = -1;

    for(int i=0; i < tFant; i++)
    {
        if( listFantasma[i].id == id && listFantasma[i].isEmpty == 0)
        {
            indice = i;
            break;
        }
    }
    return indice;
}

/** \brief Modifica los valores que desee del ITEM por Id.
 *
 * \param listFantasma[] Array del tipo estructura en el cual se va a modificar al empleado.
 * \param tFant Longitud/tama�o del Array de estructura.
 * \return int Retorna [0] si hubo un ERROR - [1] Todo OK.
 *
 */
int modificarFantasma(eFantasma listFantasma[],int tFant)
{
    int todoOk = 0;
    int id;
    int index;
    //int flagValid = 0;
    //int flagValidOrq = 0;

    system("cls");
	printf("\n--Modificar musico--\n");

    imprimirFantasmas(listFantasma,tFant);

    getInt(&id,"Ingrese ID: ","Error\n",1,10000,2);

    index = buscarPorIdFantasma(listFantasma,tFant,id);

    if(index == -1)
    {
        printf("\nNo existe un --GENERICO-- con ese ID\n\n");
    }
    else
    {

        switch(menuModifFantasma())
        {
            case 1:
                getString(listFantasma[index].nombre,"\nIngrese nuevo nombre: ", "Error. debe contener entre 2 y 35 caracteres",2,35,2);
                todoOk = 1;
                break;

            case 2:
                getString(listFantasma[index].apellido,"\nIngrese nuevo apellido: ","Error. debe contener entre 2 y 35 caracteres",2,35,2);
                todoOk = 1;
                break;

            case 3:
                getFloat(&listFantasma[index].salario,"\nEntre <1.0 - 10000000.0 num float.>\nIngrese nuevo salario: ","\nERROR, debe ingresar un numero",1.0,10000000.0,2);
                todoOk = 1;
                break;

            case 4:
                getInt(&listFantasma[index].edad,"\nIngrese nueva edad: ","Error debe estar entre 1 y 100",1,100,2);
                todoOk = 1;
                break;
            case 5:
                printf("\nSe ha cancelado la modificacion.\n\n");
                break;
            default:
                printf("\nOpcion invalida!\n\n");

            /*ESTO DEL TP DE ORQUESTA
            case 1:
                getString(listMusico[index].nombre,"Ingrese nuevo nombre: ", "Error. debe contener entre 2 y 35 caracteres",2,35,2);
                todoOk = 1;
                break;
            case 2:

                //FALTA TESTEAR, FALTA MOSTRAR A QUE ORQUESTA PERTENECE EL MUSICO ANTES DE MODIFICARLA CLARO...

                //imprimirOrquestas(listOrquesta,tOrq);
                getInt(&listMusico[index].idOrquesta,"Ingrese nueva orquesta donde pertenece: ","Error, reingrese\n",1,10000,3);
                todoOk = 1;
                break;*/
        }

    }

    return todoOk;
}

/** \brief Muestra un menu de opciones para modificar al ITEM.
 *
 * \return int La opcion elegida.
 *
 */
int menuModifFantasma()
{
    int option;
    printf("\n--MODIFICAR --GENERICO----\n\n");
    printf("\n*Elija que desea modificar*\n");
    printf("1 - Modificar nombre: \n2 - Modificar apellido: \n3 - Modificar salario: \n4 - Modificar edad: \n5 - salir\n");
    getInt(&option,"Elija opcion: ", "Error. opcion invalida\n",1,5,2);

    //IMPORTANTE CAMBIAR LOS LIMITES DE OPCION!!!!!!!!!!!!!!!!!!

    return option;
}


/** \brief Elimina el ITEM de manera l�gica con el Id pasado por parametro.
 *
 * \param listFantasma[] Array del tipo estructura en el cual se va a eliminar al ITEM.
 * \param tFant Array del tipo estructura en el cual se va a eliminar al empleado.
 * \return int Retorna [0] si hubo un ERROR - [1] Todo OK.
 *
 */
int bajaFantasma(eFantasma listFantasma[],int tFant)
{
    int id;
    int index;
    char confirma;
    int todoOk = 0;

    imprimirFantasmas(listFantasma,tFant);


    getInt(&id,"\nIngrese ID a dar de baja: ","Error",1000,10000,2);
    //MODIFICAR ESTO A MEDIDA QUE TENGA DE ID


    //BUSCAR ALUMNO...
    index = buscarPorIdFantasma(listFantasma,tFant,id);


    if(index == -1)
    {
        printf("\nNo existe --GENERICO-- con ese ID.\n");
        printf("\n...Redireccionando...\n\n");
    }
    else
    {
        printf("\n\n");
        printf("  ID       NOMBRE     APELLIDO     EDAD       SALARIO\n");
        printf("  --       ------     --------     ----       -------\n\n");
        //printf("\nACA ENTRO??\n");
        mostrarUnFantasma(listFantasma[index]);

        printf("confirma baja? <s/n>: ");
        fflush(stdin);
        scanf("%c",&confirma);

        if(confirma == 's')
        {
            listFantasma[index].isEmpty = 1;//1 ES LIBRE.
            printf("\nBaja exitosa.\n\n");
            todoOk = 1;
        }
        else if(confirma == 'n')
        {
            printf("\nSe ha cancelado la operacion.\n\n");
        }
    }

    return todoOk;
}


/** \brief Carga 20 ITEMS con sus respectivos:
 *         -Nombres.
 *         -Apellidos.
 *         -Salarios.
 *         -Edades.
 *
 * \param listFantasma[] Array del tipo estructura de empleados.
 * \param tFant Array del tipo estructura de empleados.
 * \return void Retorna el ultimo Id.
 *
 */
void hardCodearFantasmasConId(eFantasma listFantasma[],int tFant,int cant)
{
    //eFantasma bFantasma; //BUFFER

    eFantasma bFantasma =  {"Yago","Rodi",21,15000};




    /*char nombre[] [50] ={"Yago","Camila","Facundo","Joaquin","Humberto","Norma","Mario","David","Lucia","Hugo","Daniel","Alba","Adrian","Martin","Sara","Carla","Claudia","Valeria","Paula","Sofia"};

    char apellido[] [50] = {"Rodi","Roy","Toro","Vasquez","Gomez","Perez","Pereyta","Torres","Medina","Acosta","Sanchez","Fernandez","Rodriguez","Molina","Cabrera","Diaz","Perez","Dominguez","Luna","Godoy"};

    //PUEDE IR O NO...
    float salario[] = {150000,140000,6000,5000,45000,75000,13000,41000,29000,36000,12000,4500,1000,7500,9500,46000,120000,100000,45500,4000};

    int edad[] = {19,5,50,41,15,9,17,27,44,36,30,15,13,21,28,34,39,48,44,40};

    for(int i = 0; i<20; i++)//EN EL SEGUNDO PARAMETRO " i < LAS COSAS QUE TENGO HARDCODEADAS".
    {
        strcpy(bFantasma.nombre,nombre[i]);
        strcpy(bFantasma.apellido,apellido[i]);
        bFantasma.salario = salario[i];
        bFantasma.edad = edad[i];

        altaFantasmaPorId(listFantasma,100,bFantasma);

        /*strcpy(bMusico.nombre,nombre[i]);
        strcpy(bMusico.apellido ,apellido[i]);
        bMusico.edad = edad[i];

        altaMusicoPorId(listMusico,100,bMusico);
    }*/

    if(cant <= tFant && cant <=2)
    {
       for(int i = 0; i<1; i++)
    {
        listFantasma[i] = bFantasma;
        altaFantasmaPorId(listFantasma,100,bFantasma);
    }

    }


}





