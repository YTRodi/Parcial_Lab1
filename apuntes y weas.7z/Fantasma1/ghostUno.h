typedef struct
{
    char nombre[50];
    char apellido[50];
    int edad;
    float salario;
    int id;
    //OTROS ID QUE PUEDE LLEGAR A TENER...
    //int idOrquesta;
    //int idInstrumento;
    int isEmpty;
}eFantasma;

int menuFantasmaGeneralUno();

void inicializarFantasma(eFantasma listFantasma[], int tFant);
int buscarLibreFantasma(eFantasma listFantasma[], int tFant);
void mostrarUnFantasma(eFantasma listFantasma);
int imprimirFantasmas(eFantasma listFantasma[],int tFant);

//ALTA FANTASMA
int altaFantasmaPorId(eFantasma listFantasma[], int tFant, eFantasma bufferFantasma);
int altaFantasmaMaestra(eFantasma listFantasma[],int tFant);

//MODIFICACION FANTASMA
//ES BUSCAR ALUMNO....
int buscarPorIdFantasma(eFantasma listFantasma[],int tFant, int id);
int modificarFantasma(eFantasma listFantasma[],int tFant);
int menuModifFantasma();

//BAJA FANTASMA
int bajaFantasma(eFantasma listFantasma[],int tFant);

//HARDCODEO FANTASMA
//void hardCodearFantasmasConId(eFantasma listFantasma[],int tFant);
void hardCodearFantasmasConId(eFantasma listFantasma[],int tFant,int cant);
